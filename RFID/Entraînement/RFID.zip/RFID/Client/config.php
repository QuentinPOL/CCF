<?php

    $config = array(
        "db_host" => "192.168.65.93",
        "db_name" => "carter",
        "db_user" => "Root",
        "db_pass" => "Root",
    )

?>