
# New Feature - COM wrapper for uFCoder library

Implemented Component Object Model wrapper for uFCoder library.

```
COMuFCoder-x86.dll
```

## How to register COM library

```
regasm COMuFCoder-x86.dll /codebase
```
response:
```
Microsoft .NET Framework Assembly Registration Utility version 4.7.3056.0
for Microsoft .NET Framework version 4.7.3056.0
Copyright (C) Microsoft Corporation.  All rights reserved.

Types registered successfully
```
