#pragma once
class camera
{
private : 

public :
	camera();
	~camera();
	void sendOn();
	void sendOff();
	void sendLeft();
	void sendRight();
	void sendTop();
	void sendBottom();
	void reset();
	void sendOui();
	void sendNon();

};

